
---
layout: page
title: About
permalink: /about/
---

Danipa Business Systems Inc. has operated since **2006**, delivering enterprise-grade Java consulting. Today, we are focused on building the **Danipa Financial Technology Platform** to power payments and remittances across Africa.

**Contact:** hello@danipa.com (placeholder)
