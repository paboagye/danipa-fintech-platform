
---
layout: page
title: Roadmap
permalink: /roadmap/
---

## Transition Roadmap
- **2025**: Platform stack, MoMo Remittance integration, rebranding & website relaunch.
- **2026**: Expand to additional payment providers (PayPal, Stripe).
- **2027+**: Scale across Africa to drive financial inclusion.
